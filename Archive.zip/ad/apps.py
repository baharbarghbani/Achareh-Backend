from django.apps import AppConfig


class AdConfig(AppConfig):
    name = 'ad'
